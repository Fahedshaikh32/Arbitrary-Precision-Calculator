#include "header.h"
char *builtins[] = {"echo", "printf", "read", "cd", "pwd", "pushd", "popd", "dirs", "let", "eval",
					"set", "unset", "export", "declare", "typeset", "readonly", "getopts", "source", "exit", "exec", "shopt", "caller", "true", "type", "hash", "bind", "help", "jobs", "fg", "bg", NULL};

char command[20];		   // To store the command
extern char *ext_cmd[154]; // Increased size to 154
extern int status;		   // To store the status of last executed command
struct stop arr[50];	   // To store stopped processes

int stop_count = 0; // Count of stopped processes

/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> */
void extract_external_commands(char **external_commands) // Function to extract external commands from file
{
	int fd = open("ext_commands.txt", O_RDONLY, 0666); // Open the file
	if (fd < 0)										   // Check for errors
	{
		perror("Failed to open ext_commands.txt"); // Print error message
		exit(1);								   // Exit the program
	}

	char arr[50]; // To store each command
	char ch;	  // To read each character
	int i = 0;
	int idx = 0;

	while ((read(fd, &ch, 1)) > 0) // Read each character
	{
		if (ch == '\n')
		{
			arr[i] = '\0';
			external_commands[idx] = malloc(strlen(arr) + 1); // Allocate memory for command

			strcpy(external_commands[idx], arr); // Copy command to array
			// printf("%s\n",external_commands[idx]);

			idx++;
			i = 0;
		}
		else
		{
			arr[i++] = ch; // Store character in array
		}
	}

	external_commands[idx] = NULL; //	 Null terminate the array
	close(fd);					   // Close the file
}
/* <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< */

/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> */
char *get_command(char *input_string) // Function to get the command from input string
{

	int i = 0; // Index for input string

	while (input_string[i] != ' ' && input_string[i] != '\0') // Loop until space or end of string
	{
		command[i] = input_string[i]; //	 Copy character to command
		i++;						  // Increment index
	}

	command[i] = '\0'; // Null terminate the command

	return command; // Return the command
}
/* <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< */


/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> */

int check_command_type(char *command) // Function to check the type of command
{
	for (int i = 0; builtins[i]; i++) // Loop through built-in commands
	{
		if (strcmp(command, builtins[i]) == 0) // Compare command with built-in command
		{
			return BUILTIN; // Return BUILTIN if match found
		}
	}
	for (int i = 0; ext_cmd[i]; i++) // Loop through external commands
	{
		if (strcmp(command, ext_cmd[i]) == 0) // Compare command with external command
		{
			return EXTERNAL; //	Return EXTERNAL if match found
		}
	}

	return NO_COMMAND;
}
/* <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< */

/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> */
void execute_internal_commands(char *input_string) // Function to execute built-in commands
{
	if (strncmp(input_string, "exit", 4) == 0) // Exit command
	{
		exit(0); // Exit the program
	}
	else if (strncmp(input_string, "pwd", 3) == 0)
	{
		char buff[50]; // Buffer to store current working directory

		getcwd(buff, 50);

		printf("%s\n", buff);
	}
	else if (strncmp(input_string, "cd", 2) == 0) // Change directory command
	{
		char *token = strtok(input_string, " ");

		token = strtok(NULL, " ");

		chdir(token); // Change directory
	}
	else if (strncmp(input_string, "echo $$", 7) == 0) // Print process ID
	{
		printf("%d\n", getpid());
	}
	else if (strncmp(input_string, "echo $?", 7) == 0) // Print status of last executed command
	{
		if (WIFEXITED(status))
		{
			printf("%d\n", WEXITSTATUS(status)); // Print exit status
		}
		else
		{
			printf("%d\n", 555);
		}
	}
	else if (strncmp(input_string, "echo $SHELL", 11) == 0) // Print shell path
	{
		printf("%s\n", getenv("SHELL"));
	}
	else if (strncmp(input_string, "jobs", 4) == 0) // Print stopped jobs
	{
		for (int i = 0; i < stop_count; i++)
		{
			printf("[%d] Stopped\t %s [%d]\n", i + 1, arr[i].name, arr[i].spid);
		}
	}
	else if (strncmp(input_string, "fg", 2) == 0) //	 Bring stopped job to foreground
	{
		if (stop_count > 0)
		{
			kill(arr[stop_count - 1].spid, SIGCONT);
			waitpid(arr[stop_count - 1].spid, &status, WUNTRACED);
			stop_count--;
		}
	}
	else if (strncmp(input_string, "bg", 2) == 0) // Resume stopped job in background
	{
		if (stop_count > 0)
		{
			signal(SIGCHLD, signal_handler); // Set signal handler for child process status change

			kill(arr[stop_count - 1].spid, SIGCONT);

			stop_count--;
		}
	}
}
/* <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< */

/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> */
void execute_external_commands(char *input_string) // Function to execute external commands
{
	for (int i = strlen(input_string) - 1; i >= 0; i--) // Loop from end of string to remove spaces
	{
		if (input_string[i] == ' ') // Check if character is space
		{
			input_string[i] = '\0'; // Replace space with null character
		}
		else
		{
			break; // Stop loop when non-space is found
		}
	}

	int c = 0; // Variable to count number of arguments

	for (int i = 0; input_string[i] != '\0'; i++) // Loop through input string
	{
		if (input_string[i] == ' ' || input_string[i + 1] == '\0') // Check space or end of string
		{
			c++; // Increment argument count
		}
	}

	char **argv = malloc((c + 1) * sizeof(char *)); // Allocate memory for argument array
	int v = 0;										// Index for argv array
	int p = 0;										// Flag to check pipe presence
	char a[50];										// Temporary array to store argument

	for (int i = 0, j = 0;; i++) // Infinite loop to split input string
	{
		if (input_string[i] == ' ' || input_string[i] == '\0') // Check space or end of string
		{
			if (j > 0) // Check if characters were stored
			{
				a[j] = '\0';					 // Null terminate argument string
				argv[v] = malloc(strlen(a) + 1); // Allocate memory for argument
				strcpy(argv[v], a);				 // Copy argument to argv
				v++;							 // Move to next argv index
				j = 0;							 // Reset temporary index
				if (input_string[i] == '\0')	 // Check end of string
				{
					break; // Exit loop
				}
			}
		}
		else
		{
			a[j++] = input_string[i]; // Store character in temporary array
		}
	}

	argv[v] = NULL; // Null terminate argv array

	for (int i = 0; i < v; i++) // Loop through arguments
	{
		if (strcmp(argv[i], "|") == 0) // Check if argument is pipe symbol
		{
			p = 1; // Set pipe flag
			break; // Exit loop
		}
	}

	if (p == 0) // If no pipe is present
	{
		if (execvp(argv[0], argv) < 0) // Execute command normally
		{
			printf("Command not found\n"); // Print error message
		}
	}

	else // If pipe symbol is present
	{
		int arr[v];			// Array to store command positions
		int pipe_count = 0; // Count number of pipes
		int idx = 0;		// Index for arr array

		arr[idx++] = 0; // Store starting index of first command

		for (int i = 0; i < v; i++) // Loop through arguments
		{
			if (strcmp(argv[i], "|") == 0) // Check for pipe symbol
			{
				argv[i] = NULL;		// Replace pipe with NULL
				arr[idx++] = i + 1; // Store next command index
				pipe_count++;		// Increment pipe count
			}
		}

		int prev_fd = -1; // File descriptor for previous pipe
		int fd[2];		  // Array to store pipe file descriptors

		for (int i = 0; i <= pipe_count; i++) // Loop for each piped command
		{
			if (i != pipe_count) // If not last command
			{
				if (pipe(fd) == -1) // Create pipe
				{
					perror("pipe"); // Print pipe error
					exit(1);		// Exit program
				}
			}

			pid_t pid = fork(); // Create child process

			if (pid == 0) // Child process
			{
				if (prev_fd != -1) // Check if previous pipe exists
				{
					dup2(prev_fd, 0); // Redirect input from previous pipe
					close(prev_fd);	  // Close previous pipe
				}

				if (i != pipe_count) // If not last command
				{
					dup2(fd[1], 1); // Redirect output to pipe
					close(fd[0]);	// Close read end
					close(fd[1]);	// Close write end
				}

				execvp(argv[arr[i]], argv + arr[i]); // Execute command
				perror("execvp");					 // Print exec error
				exit(1);							 // Exit child process
			}

			// Parent process
			if (prev_fd != -1)	// Check if previous pipe exists
				close(prev_fd); // Close previous pipe

			if (i != pipe_count) // If not last command
			{
				close(fd[1]);	 // Close write end
				prev_fd = fd[0]; // Store read end for next command
			}
		}

		// Wait for all child processes
		for (int i = 0; i <= pipe_count; i++)
			wait(NULL); // Wait for each process
	}
}
/* <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< */